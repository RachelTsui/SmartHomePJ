function addone(){
    var ID = document.getElementById("ID").value;
    var Name = document.getElementById("Name").value;
    var Cycle = document.getElementById("Cycle").value;
    var kind = document.getElementById("Kind").value;
    var board = document.querySelector("#insights");
    var boardsmall = document.querySelector("#device")
    var message = ID + "-" + "-" + Name + "-" +Cycle+"-"+kind;
    var newequip = document.createElement("div");
    newequip.classList.add("themepallete");
    newequip.innerText = message;
    boardsmall.appendChild(newequip); 
    board.appendChild(boardsmall);
    console.log(message);
}